package com.kafka.basickafkaprogram.producer;

import java.util.Properties;
import java.util.Random;
import java.util.concurrent.ExecutionException;

import com.kafka.basickafkaprogram.avro.Person;
import org.apache.kafka.clients.producer.Callback;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.config.SslConfigs;
import org.apache.kafka.common.serialization.StringSerializer;

import io.confluent.kafka.serializers.AbstractKafkaAvroSerDeConfig;
import io.confluent.kafka.serializers.KafkaAvroSerializer;


public class PersonKafkaProducer {

    private static final String SCHEMA_REGISTRY_URL = "https://psrc-v6px5.westeurope.azure.confluent.cloud";

    public static void main(String[] args) throws InterruptedException, ExecutionException {

        PersonKafkaProducer kAvroProducer = new PersonKafkaProducer();

        while(true) {
            long rand = new Random().nextLong();
            if(rand % 2 == 0) {
                kAvroProducer.sendRecord("test", null, new Person( rand, "Ross", "Geller"));
            }else {
                kAvroProducer.sendRecord("test", null, new Person( rand, "Rachel", "Green"));
            }
            Thread.sleep(5000);
        }
    }

    private static Producer<String, Person> producer = null;

    public PersonKafkaProducer(){
        final Properties props = new Properties();

        props.put( ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "pkc-ldvmy.centralus.azure.confluent.cloud:9092");
        props.put( ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        props.put( ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, KafkaAvroSerializer.class);
        props.put( ProducerConfig.CLIENT_ID_CONFIG, "poc-producer");
        props.put( AbstractKafkaAvroSerDeConfig.SCHEMA_REGISTRY_URL_CONFIG, SCHEMA_REGISTRY_URL);
        props.put("basic.auth.credentials.source", "USER_INFO");
        props.put("basic.auth.user.info", "HDNO3NBLVGQQKI2Z:5cjBgow6wHlHy1KBv8sAoM1UGJKNyMEhQjd+2bkmfEYhAPLP8P5lDqc7LIe6LFl+");
        props.put("security.protocol", "SASL_SSL");
        props.put("sasl.mechanism", "PLAIN");
        props.put("ssl.endpoint.identification.algorithm", "https");
        props.put("sasl.jaas.config", "org.apache.kafka.common.security.plain.PlainLoginModule required username=\"NIAG3F7T7NHMQD73\" password=\"Ihf+/u+OzrCK25yX+5FyhbGC7wDdGXb8xywB4LIBDIHfd+G4Afbqwu/b9lASsFCq\";");

        producer = new KafkaProducer<>(props);

        Runtime.getRuntime().addShutdownHook(new Thread(){
            @Override
            public void run() {
                producer.close();
            }
        });
    }

    public void sendRecord(String topic, String key, Person value) throws InterruptedException, ExecutionException{

        ProducerRecord<String, Person> record = new ProducerRecord<String, Person>(topic, key, value);

        PersonKafkaProducer.producer.send(record, new Callback() {

            @Override
            public void onCompletion(RecordMetadata metadata, Exception exception) {

                if(metadata != null) {
                    System.out.println("Topic -> "+metadata.topic()+"; Partition -> "+metadata.partition()+
                            "; Offset -> "+metadata.offset()+"; Record -> "+value);
                }else {
                    System.err.println(exception.getLocalizedMessage());
                }

            }
        });

    }

}
