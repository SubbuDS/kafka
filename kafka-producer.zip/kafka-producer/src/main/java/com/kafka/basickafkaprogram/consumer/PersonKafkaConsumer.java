package com.kafka.basickafkaprogram.consumer;

import java.util.Arrays;
import java.util.Properties;

import com.kafka.basickafkaprogram.avro.Person;
import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.serialization.StringDeserializer;

import io.confluent.kafka.serializers.AbstractKafkaAvroSerDeConfig;
import io.confluent.kafka.serializers.KafkaAvroDeserializer;

public class PersonKafkaConsumer {

    private static final String SCHEMA_REGISTRY_URL = "https://psrc-v6px5.westeurope.azure.confluent.cloud";

    public static void main(String[] args) {

        PersonKafkaConsumer kConsumer = new PersonKafkaConsumer();
        kConsumer.startConsumer("test");

    }

    private Consumer<String, Person> consumer = null;

    public PersonKafkaConsumer(){

        final Properties props = new Properties();

        props.put( ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, "pkc-ldvmy.centralus.azure.confluent.cloud:9092");
        props.put( ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        props.put( ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, KafkaAvroDeserializer.class);
        props.put( ConsumerConfig.GROUP_ID_CONFIG, "test-avro-consumer-1");
        props.put( ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
        props.put( AbstractKafkaAvroSerDeConfig.SCHEMA_REGISTRY_URL_CONFIG, SCHEMA_REGISTRY_URL);
        props.put("basic.auth.credentials.source", "USER_INFO");
        props.put("basic.auth.user.info", "HDNO3NBLVGQQKI2Z:5cjBgow6wHlHy1KBv8sAoM1UGJKNyMEhQjd+2bkmfEYhAPLP8P5lDqc7LIe6LFl+");
        props.put("security.protocol", "SASL_SSL");
        props.put("sasl.mechanism", "PLAIN");
        props.put("ssl.endpoint.identification.algorithm", "https");
        props.put("sasl.jaas.config", "org.apache.kafka.common.security.plain.PlainLoginModule required username=\"NIAG3F7T7NHMQD73\" password=\"Ihf+/u+OzrCK25yX+5FyhbGC7wDdGXb8xywB4LIBDIHfd+G4Afbqwu/b9lASsFCq\";");

        consumer = new KafkaConsumer<>(props);

        Runtime.getRuntime().addShutdownHook(new Thread(){
            @Override
            public void run() {
                consumer.close();
            }
        });
    }

    public void startConsumer(String topic){
        consumer.subscribe(Arrays.asList(topic));

        while (true) {
            final ConsumerRecords<String, Person> consumerRecords =
                    consumer.poll(1000);

            consumerRecords.forEach(record -> {
                System.out.printf("Consumer Record:(%d, %s, %d, %d)\n",
                        record.key(), record.value(),
                        record.partition(), record.offset());
            });

            consumer.commitAsync();
        }

    }

}
